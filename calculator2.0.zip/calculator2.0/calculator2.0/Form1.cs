﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace calculator2._0
{
    //rip my style, 30 minutes on clock is too frightening
    //commenting real fast hopefully nothing is wrong as I am running out of time, the base case works
    public partial class Form1 : Form
    {
        //bunch of variables
        public string question = "";
        public string answer = "";
        public string[] symbols = new string[2];
        public double[] numbers = new double[2];
        public string questPart = "";
        public string questPartSym = "";
        public int counterSym = 0;
        public int counterNum = 0;
        public bool restart = false;


        //initialize stuff
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = question + Environment.NewLine + "------------" + Environment.NewLine + answer;
        }

        //adds a number to the string while checking for edge cases and adds the symbol to the array
        public void addNum(int aNum)
        {
            //checks if it needs to be restarted, if it does restarts stuff
            if(restart == true)
            {
                answer = "";
                question = "";
                restart = false;
            }

            //edge case that i dont even know if i need anymore for negatives
            if (questPartSym.Length > 1)
            {
                if (questPartSym.Substring(questPartSym.Length - 1).Equals("-"))
                {
                    if (questPartSym.Substring(questPartSym.Length - 2, 1).Equals("-"))
                    {
                        System.Windows.Forms.Application.Exit();
                    }
                }
                else
                {
                    System.Windows.Forms.Application.Exit();
                }

            }

            //adds number to question
            question += aNum;
            questPart += aNum;
            textBox1.Text = question + Environment.NewLine + "------------" + Environment.NewLine + answer;

            //adds symbol to array only if there is a symbol to put in there
            if (questPartSym != "")
            {
                //increases size of array if needed
                symbols[counterSym] = questPartSym.Substring(0);
                if (counterSym >= symbols.Length - 1)
                {
                    string[] symbols2 = new string[symbols.Length * 2];
                    for (int i = 0; i < symbols.Length; i++)
                    {
                        symbols2[i] = symbols[i];
                    }
                    symbols = new string[symbols.Length * 2];
                    for (int i = 0; i < symbols.Length; i++)
                    {
                        symbols[i] = symbols2[i];
                    }
                }
                questPartSym = "";
                counterSym++;
            }
        }

        //same as last one except gets rid of the symbol stuff and the edge case
        public void addNum(string aNum)
        {
            if (restart == true)
            {
                question = "";
                answer = "";
                restart = false;
            }

            /*if (questPartSym.Length > 1)
            {
                if (questPartSym.Substring(questPartSym.Length - 1).Equals("-"))
                {
                    if (questPartSym.Substring(questPartSym.Length - 2, 1).Equals("-"))
                    {
                        System.Windows.Forms.Application.Exit();
                    }
                }
                else
                {
                    System.Windows.Forms.Application.Exit();
                }

            }*/

            question += aNum;
            questPart += aNum;
            textBox1.Text = question + Environment.NewLine + "------------" + Environment.NewLine + answer;

            /*if (questPartSym != "")
            {
                
                symbols[counterSym] = questPartSym.Substring(0);
                //MessageBox.Show(Convert.ToString(numbers[0]));
                if (counterSym >= symbols.Length - 1)
                {
                    string[] symbols2 = new string[symbols.Length * 2];
                    for (int i = 0; i < symbols.Length; i++)
                    {
                        symbols2[i] = symbols[i];
                    }
                    symbols = new string[symbols.Length * 2];
                    for (int i = 0; i < symbols.Length; i++)
                    {
                        symbols[i] = symbols2[i];
                    }
                }
                questPartSym = "";
            }*/
        }

        //adds a symbol to the question and adds a number to the number array
        public void addSym(string aChar)
        {
            //sees if there is error
            if(questPartSym != "")
            {
                System.Windows.Forms.Application.Exit();
            }
            //sees if there is restart
            else if (restart)
            {
                question = answer;
                questPart = answer;
                restart = false;
            }

            //adds symbol to question
            question += aChar;
            questPartSym += aChar;

            //prints
            textBox1.Text = question + Environment.NewLine + "------------" + Environment.NewLine + answer;
            
            //adds number to array
            numbers[counterNum] = Convert.ToDouble(questPart);
            counterNum++;

            //increases array size
            if (counterNum >= numbers.Length)
            {
                double[] numbers2 = new double[numbers.Length * 2];
                for(int i = 0; i < numbers.Length; i++)
                {
                    numbers2[i] = numbers[i];
                }
                numbers = new double[numbers.Length * 2];
                for (int i = 0; i < numbers.Length; i++)
                {
                    numbers[i] = numbers2[i];
                }
            }
            
            //resets num
            questPart = "";
        }

        //don't know if i need that
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //dont know if i need that
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        //adds one
        private void buttonadd1_Click(object sender, EventArgs e)
        {
            addNum(1);
        }

        //adds two
        private void buttonadd2_Click(object sender, EventArgs e)
        {
            addNum(2);
        }

        //adds three
        private void buttonadd3_Click(object sender, EventArgs e)
        {
            addNum(3);
        }

        //adds four
        private void buttonadd4_Click(object sender, EventArgs e)
        {
            addNum(4);
        }

        //adds five
        private void buttonadd5_Click(object sender, EventArgs e)
        {
            addNum(5);
        }

        //adds six
        private void buttonadd6_Click(object sender, EventArgs e)
        {
            addNum(6);
        }

        //adds seven
        private void buttonadd7_Click(object sender, EventArgs e)
        {
            addNum(7);
        }

        //adds eight
        private void buttonadd8_Click(object sender, EventArgs e)
        {
            addNum(8);
        }

        //adds nine
        private void buttonadd9_Click(object sender, EventArgs e)
        {
            addNum(9);
        }

        //adds zero
        private void buttonadd0_Click(object sender, EventArgs e)
        {
            addNum(0);
        }
        //end of nums

        //resets everything
        private void buttondelete_Click(object sender, EventArgs e)
        {
            //FIX
            answer = "";
            question = "";
            symbols = new string[2];
            numbers = new double[2];
            questPart = "";
            questPartSym = "";
            counterSym = 0;
            counterNum = 0;

            textBox1.Text = question + Environment.NewLine + "------------" + Environment.NewLine + answer;

        }

        //adds negative
        private void buttonopp_Click(object sender, EventArgs e)
        {
            //bunch of conditions to see what characters are before and whether or not to add it to as a symbol or as a number
            if (question != "" && question.Length >= 1 && answer == "")
            {
                string lastChar = question.Substring(question.Length - 1);
                if (lastChar.Equals("-") || lastChar.Equals("+") || lastChar.Equals("*") || lastChar.Equals("/") || lastChar.Equals("%"))
                {
                    if (question.Substring(question.Length - 2, 1).Equals("-"))
                    {
                        System.Windows.Forms.Application.Exit();
                    }
                    addNum("-");
                }
                else
                {
                    addSym("-");
                }
            }
            else
            {
                addNum("-");
            }
        }

        //mod
        private void buttonmod_Click(object sender, EventArgs e)
        {
            addSym("%");
        }

        //divides
        private void buttondivide_Click(object sender, EventArgs e)
        {
            addSym("/");
        }

        //addition
        private void buttonplus_Click(object sender, EventArgs e)
        {
            addSym("+");
        }

        //subtraction
        private void buttonminus_Click(object sender, EventArgs e)
        {
            //bunch of conditions to see what characters are before and whether or not to add it to as a symbol or as a number
            if (question != "" && question.Length >= 1 && answer == "")
            {
                string lastChar = question.Substring(question.Length - 1);
                if (lastChar.Equals("-") || lastChar.Equals("+") || lastChar.Equals("*") || lastChar.Equals("/") || lastChar.Equals("%"))
                {
                    if (question.Substring(question.Length - 2, 1).Equals("-"))
                    {
                        System.Windows.Forms.Application.Exit();
                    }
                    addNum("-");
                }
                else
                {
                    addSym("-");
                }
            }
            else
            {
                addNum("-");
            }
        }

        //multiplies
        private void buttonmultiply_Click(object sender, EventArgs e)
        {
            addSym("*");
        }

        //decimal
        private void buttondecimal_Click(object sender, EventArgs e)
        {
            //sees if symbol is before and gives error if so
            string ans = question.Substring(question.Length - 1);
            if (ans.Equals(".") || ans.Equals("%") || ans.Equals("*") || ans.Equals("+") || ans.Equals("-") || ans.Equals("/"))
            {
                System.Windows.Forms.Application.Exit();
            }

            //adds decimal to question
            question += ".";
            questPart += ".";
            textBox1.Text = question + Environment.NewLine + "------------" + Environment.NewLine + answer;

        }

        //equals
        private void buttonequal_Click(object sender, EventArgs e)
        {
            //sees if last character is a symbol and if so error
            string compare = question.Substring(question.Length - 1);
            if (compare.Equals("%") || compare.Equals("*") || compare.Equals("/") || compare.Equals("+") || compare.Equals("-"))
            {
                System.Windows.Forms.Application.Exit();
            }


            //adds the last number to array
            numbers[counterNum] = Convert.ToDouble(questPart);
            counterNum++;

            //more variables used only for computation
            //double[] numArr2 = new double[counterNum];
            //string[] symArr2 = new string[counterSym];
            int lim = counterSym;
            int prev = 0;
            int now = 0;
            int next = 1;
            int count = 0;

            //array of symbols to go through Order of Operations
            string[] syms = new string[5] { "*", "/", "%", "+", "-" };
            
            //goes through operations
            for (int i = 0; i < syms.Length; i++)
            {
                
                //MessageBox.Show(Convert.ToString(numbers[prev]));
                //goes through list
                for (int j = 0; j < lim; j++)
                {
                    //does operation
                    if (symbols[j] == syms[i])
                    {
                        count++;
                        if(syms[i] == "*")
                        {
                            numbers[prev] = numbers[now] * numbers[next];
                        }
                        else if (syms[i] == "/")
                        {
                            numbers[prev] = numbers[now] / numbers[next];
                        }
                        else if (syms[i] == "%")
                        {
                            double sum = 0;
                            if(numbers[now] >= sum)
                            {
                                if(numbers[next] >= sum)
                                {
                                    while (numbers[now] >= sum)
                                    {
                                        sum += numbers[next];
                                    }
                                    sum -= numbers[next];
                                    numbers[prev] = numbers[now] - sum;
                                }
                                else
                                {
                                    numbers[next] *= -1;
                                    while (numbers[now] >= sum)
                                    {
                                        sum += numbers[next];
                                    }
                                    sum -= numbers[next];
                                    numbers[prev] = -1 * (numbers[now] - sum);
                                }
                            }
                            else
                            {
                                if (numbers[next] >= sum)
                                {
                                    numbers[now] *= -1;
                                    while (numbers[now] >= sum)
                                    {
                                        sum += numbers[next];
                                    }
                                    sum -= numbers[next];
                                    numbers[prev] = -1 * (numbers[now] - sum);
                                }
                                else
                                {
                                    numbers[now] *= -1;
                                    numbers[next] *= -1;
                                    while (numbers[now] >= sum)
                                    {
                                        sum += numbers[next];
                                    }
                                    sum -= numbers[next];
                                    numbers[prev] = numbers[now] - sum;
                                }
                            }
                        }
                        else if (syms[i] == "+")
                        {
                            numbers[prev] = numbers[now] + numbers[next];
                        }
                        else
                        {
                            numbers[prev] = numbers[now] - numbers[next];
                        }
                        //prev++;
                        symbols[j] = "";

                    }
                    //replaces numbers
                    else
                    {
                        
                        symbols[prev] = symbols[j];
                        //prev++;
                        numbers[prev+count] = numbers[j+count];
                        prev++;
                        //MessageBox.Show(symbols[j]);
                        //MessageBox.Show(Convert.ToString(numbers[j]));
                        now = next;
                    }
                    //prev++;
                    next++;
                }
                //resets variables
                lim = prev;
                prev = 0;
                now = 0;
                count = 0;
                next = 1;
            }

            //gets answer and resets everything except answer and question
            answer = Convert.ToString(numbers[0]);
            symbols = new string[2];
            numbers = new double[2];
            questPart = "";
            questPartSym = "";
            counterSym = 0;
            counterNum = 0;

            //prints
            textBox1.Text = question + Environment.NewLine + "------------" + Environment.NewLine + answer;

            //restarts on next button pressed
            restart = true;
        }
    }
}
